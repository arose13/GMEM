GMEM
===============================

Author: Stephen Anthony Rose
Fork of MERF

Overview
--------

Random Effects models for _any ML model_.
This is a generalisation of a Mixed Effects Random Forest model

Installation / Usage
--------------------

To install use pip:

    $ pip install gmem


Or clone the repo:

    $ git clone https://github.com/arose13/gmem.git
    $ python setup.py install
    
Contributing
------------

Me (Stephen Anthony Rose)

Example
-------

To be announced.